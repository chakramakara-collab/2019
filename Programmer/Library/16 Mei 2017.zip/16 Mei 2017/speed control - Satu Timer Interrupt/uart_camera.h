#ifndef UART_CAMERA_H_INCLUDED
#define	UART_CAMERA_H_INCLUDED

void init_camera();
void USART3_IRQHandler(void);

#endif
