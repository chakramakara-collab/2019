/* Test STT_GNU_IFUNC symbols with PIE.  */

#include "ifuncmain5.c"
