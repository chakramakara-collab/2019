/* Test STT_GNU_IFUNC symbols with -fPIC and no DSO.  */

#include "ifuncmain5.c"
