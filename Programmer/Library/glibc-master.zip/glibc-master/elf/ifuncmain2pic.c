/* Test STT_GNU_IFUNC symbols with -fPIC.  */

#include "ifuncmain2.c"
