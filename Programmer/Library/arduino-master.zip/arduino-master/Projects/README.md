![Arduino &amp; Fritzing Sketches](https://raw.github.com/manifestinteractive/arduino/master/assets/logo.png "Arduino &amp; Fritzing Sketches")
Projects Folder
-------
Each Arduino project also has it's own *Fritzing* folder that contains a .fzz file.  I have already rendered out the breadboard & schematic images.  You an also find an HTML file in the root of each project containing the Bill of Materials which lists the items you will need for that project.