![Arduino &amp; Fritzing Sketches](https://raw.github.com/manifestinteractive/arduino/master/assets/logo.png "Arduino &amp; Fritzing Sketches")
RFID READER
-------
RFID Reader ID-12 for Arduino

The circuit:

* Disconnect the rx serial wire to the ID-12 when uploading the sketch

Created 2012-07-01