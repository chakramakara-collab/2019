#ifndef UART_NODE_H_INCLUDED
#define UART_NODE_H_INCLUDED
void init_USART2(void);
void USART2_IRQHandler(void);
void USART_InitializeTimer();
void USART_EnableTimerInterrupt();
void TIM5_IRQHandler();
void init_USART3(void);
void USART3_IRQHandler(void);
void getGamestate(void);

#endif // UART_NODE_H_INCLUDED
