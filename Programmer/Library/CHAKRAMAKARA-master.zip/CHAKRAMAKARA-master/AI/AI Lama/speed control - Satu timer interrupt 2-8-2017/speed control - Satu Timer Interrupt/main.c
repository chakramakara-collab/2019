#include "stm32f4xx_exti.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_syscfg.h"
#include "misc.h"
#include "tm_stm32f4_rotary_encoder.h"
#include "tm_stm32f4_delay.h"
#include "lcd_16x2.h"
#include "pwm_motor.h"
#include <stdio.h>
#include "speed_control.h"
#include <math.h>
#include "uart_node.h"
#define servoMid 84
#define goalX  12
#define goalY  -3
#define IHead 0
#define DHead 0
#define PHead 1
#define PI 3.14159265
#define ON 1
#define OFF 0

extern char gameState;
extern char ballXCoor;
extern char ballYCoor;
extern float movY;
extern float movX;


float KaP = 1;
float KaD = 2;
float KaI = 0;
float ball,errorBall,derivErrorBall,intErrorBall,prevErrorBall;
float heading;
float head,errorHead,derivErrorHead,intErrorHead,prevErrorHead;
float headGoal;

/*
 * Update Note 8 Februari 2017
 * - heading merupakan arah robot menghadap yang di acukan saat robot baru dinyalakan dalam satuan derajat(0-360)
 * - perhitungan heading dimulai dengan menandakan mulainya perhitungan(startHeading =1) jika robot bergerak rotasi
 * yang dituliskan pada fungsi rotateClockWise dan rotateAntiClockWise di library pwm.h
 * - pergerakan selain rotate akan mematikan perhitungan(startHeading =0)
 * - perhitungan heading terdapat pada fungsi getHeading yang akan menghitung perbedaan count
 * yang dicatat pada fungsi TIM2_IRQHandler di library speedcontrol.
 *
 */


void getBall(){
	if((ballXCoor-servoMid) > -15 && (ballXCoor - servoMid) < 15){
		maju(30);
	}
	else{
		errorBall = servoMid - ballXCoor ;
		derivErrorBall = errorBall - prevErrorBall;
		intErrorBall += errorBall;
		ball = (float)KaP * errorBall + (float)KaD * derivErrorBall + (float)KaI * intErrorBall;
		if(ball>30){
			ball = 30;
		}
		else if (ball <-30){
			ball = -30;
		}
		rotateAntiClockWise(ball);
		prevErrorBall=errorBall;
	}

//	if((ballXCoor-servoMid)>15){
//		rotateClockWise(20);
//	}
//	else if ((ballXCoor-servoMid)<-15){
//		rotateAntiClockWise(20);
//	}
//	else {
//		maju(20);
//	}
}

void getGoalPos(){

 headGoal = atan((goalY-movY)/(goalX-movX))*180/PI;
 if(headGoal<360){
   headGoal = 360+headGoal;
 }
 if((heading-headGoal) > -10 && (heading - headGoal) < 10){
	 handleOff();
	 maju(30);
 }
 else{
	 handleOn();
	 if(headGoal>180){
		 rotateClockWise(10);
	 }
	 else if (headGoal<180) {
		rotateAntiClockWise(10);
	}
 }
 errorHead = headGoal - heading ;
 derivErrorHead = errorHead - prevErrorHead;
 intErrorHead += errorHead;
 head = (float)PHead * errorHead + (float)DHead * derivErrorHead + (float)IHead * intErrorHead;
 if(head>30){
  head = 30;
 }
 else if (head <-30){
  head = -30;
 }

 //rotateAntiClockWise(head);
 prevErrorHead=errorHead;

}

void gotoHeadZero(){
	 if(heading > -10 && heading < 10){
		 handleOff();
		 maju(30);
	 }
	 else{
		 handleRotateIn();
		 if(heading>180){
			 rotateAntiClockWise(10);
		 }
		 else if (heading<180) {
			rotateClockWise(10);
		}
	 }
//	 errorHead = 0 - heading ;
//	 derivErrorHead = errorHead - prevErrorHead;
//	 intErrorHead += errorHead;
//	 head = (float)PHead * errorHead + (float)DHead * derivErrorHead + (float)IHead * intErrorHead;
//	 if(head>30){
//	  head = 30;
//	 }
//	 else if (head <-30){
//	  head = -30;
//	 }
}

void tesMotor(){
	maju(50);
	Delayms(2000);
	mundur(50);
	Delayms(2000);
	kiri(50);
	Delayms(2000);
	kanan(50);
	Delayms(2000);
	baratLaut(50);
	Delayms(2000);
	tenggara(50);
	Delayms(2000);
	baratDaya(50);
	Delayms(2000);
	timurLaut(50);
	Delayms(2000);
	rotateAntiClockWise(50);
	Delayms(2000);
	rotateClockWise(50);
	Delayms(2000);
}

//void puter(int pewem)
//{
//	if(pewem>0)
//	{
//		rotateClockWise(pewem);
//	}
//	else
//	{
//		rotateAntiClockWise(-1*pewem);
//	}
//}

void tesHandle(){
	handleOn();
	Delayms(2000);
	handleOff();
	Delayms(2000);
}

void tesRotatePID(){
	    extern TM_INT_RE_Count;
	    int kesalahan, setpoin=-586, peweem, makz=100;
	    Delayms(10000);
	    //586 = 360 derajat
	    while(1)
	    {
	    	kesalahan=setpoin-TM_INT_RE_Count;
	    	peweem=1*kesalahan;
	    	if(peweem>makz) peweem=makz;
	    	else if(peweem<-makz) peweem=-makz;
	    	puter(peweem);
	    }

	    while(TM_INT_RE_Count < 290){
	    	rotateClockWise(30);

	    }
	    rotateClockWise(0);
}

void tesRotateMap(){
	int icount;
	maju(20);
	Delayms(2000);
	while(heading < (90 * icount)){
		rotateAntiClockWise(20);
	}
	rotateAntiClockWise(0);
	Delayms(2000);
	icount ++;
	if (icount > 4){
		icount = 1;
	}
}

void startMain(int refree){
	if(refree == 1 ){
		if(gameState=='s'){
			if(ballYCoor>20){
				getBall();
				handleOff();
			}
			else{
				maju(30);
				if(ballYCoor>0){
					handleRotateIn();
				}
				else{
					handleOff();
				}
				//gotoHeadZero();
			}
		}
		else{
			motorSpeed(0,0,0,0);
			handleOff();
		}
	}
	else{
		if(ballYCoor>10){
			getBall();
			handleOff();
		}
		else{
			if(ballYCoor>0){
				handleRotateIn();
			}
			else{
				handleOff();
			}
			maju(30);
		}

	}
}

int main(void)
{
	int i = 0;
	SystemInit();

	lcd_init();
	TM_DELAY_Init();

	lcd_clear();
	init_speed_control();
	init_USART();

	Delayms(7000);


    while(1)
    {
    	//motorSpeed(30,0,0,0);
    	//tesHandle();
    	//tesMotor();
    	startMain(ON);

    }
}
