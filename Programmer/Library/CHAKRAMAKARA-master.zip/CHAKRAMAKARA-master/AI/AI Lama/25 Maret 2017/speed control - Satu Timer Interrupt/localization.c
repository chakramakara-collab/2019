#include "localization.h"
#include "speed_control.h"
#include <math.h>
#include "uart_node.h"
#include "uart_camera.h"
#include "uart_kompas.h"
#include "tm_stm32f4_delay.h"
#include "lcd_16x2.h"

char lcd[16];
float KaP = 1;
float KaD = 2;
float KaI = 0;
float ball,errorBall,derivErrorBall,intErrorBall,prevErrorBall;
float ballMaju,errorBallMaju,derivErrorBallMaju,intErrorBallMaju,prevErrorBallMaju;
float heading;
float head,errorHead,derivErrorHead,intErrorHead,prevErrorHead;
float headGoal;
int headCount;
float heading, mov,movPrev, movX, movY;
extern uint16_t compassHeading;
extern char gameState;
extern char ballXCoor;
extern char ballYCoor;
extern float movY;
extern float movX;

int icount=1;

/**
 * Start main merupakan fungsi utama program robot
 * fungsi ini akan mencari bola, dan gawang
 * @param refree untuk menentukan akan menggunakan refree atau tidak
 * @param mode untuk mengarahkan ke area musuh saja atau mengarahkan ke gawang musuh
 *
 */
void startMain(int refree, int arahGawang){

	if(refree == ON ){
		if (gameState == 's') {
			if(ballYCoor>0){
				getBall();
				if(ballYCoor<20){
					handleRotateIn();
				}
				else{
					handleOff();
				}
			}
			else{
	//			if(arahGawang == ON){
	//				getGoalPos();
	//			}

	//			else{
					handleOff();
					gotoHeadZero();
	//			}
			}
		}
		else if(gameState == 'T'){
			outBall1();
		}
		else if (gameState == 't') {
			outBall2();
		}
		else{
			handleOff();
			motorSpeed(0,0,0,0);
		}

	}
	// refree off
	else{
		if(ballYCoor>0){
			getBall();
			if(ballYCoor<20){
				handleRotateIn();
			}
			else{
				handleOff();
			}
		}
		else{
//			if(arahGawang == ON){
//				getGoalPos();
//			}

//			else{
				handleOff();
				gotoHeadZero();
//			}
		}

	}
}

void outBall1()
{
	if(ballYCoor >= 40 && ballYCoor <= 50)
	{
		motorSpeed(0,0,0,0);
	}
	else if(ballYCoor < 40)
	{
		mundur(30);
	}
	else
	{
		getBall();
	}
}

void outBall2()
{
	if(ballYCoor >= 100 &&  ballYCoor <= 105)
	{
		motorSpeed(0,0,0,0);
	}
	else if(ballYCoor < 100)
	{
		mundur(30);
	}
	else
	{
		getBall();
	}
}
void penalty(){
	if(ballYCoor>2){
		//getBall();
		maju(100);
		//handleOn();
	}
	else{
		while(1){
			motorSpeed(0,0,0,0);
		}
	}
}

void printData(){
	lcd_clear();
	int xCoor,yCoor;
	xCoor = movX;
	yCoor = movY;
	sprintf(lcd,"H:%d Y:%d X:%d ",compassHeading,yCoor,xCoor);
	lcd_putsf(0,0,lcd);
	sprintf(lcd, "G:%c y:%d x:%d",gameState,ballYCoor,ballXCoor);
	lcd_putsf(0,1,lcd);
}

void getBall(void){
	if((ballXCoor-servoMid) > -15 && (ballXCoor - servoMid) < 15){
		errorBallMaju =  ballYCoor ;
		derivErrorBallMaju = errorBallMaju - prevErrorBallMaju;
		intErrorBallMaju += errorBallMaju;
		ballMaju = (float)KaP * errorBallMaju + (float)KaD * derivErrorBallMaju + (float)KaI * intErrorBallMaju;
		if(ballMaju>75){
			ballMaju = 75;
		}
		else if(ballMaju<20){
			ballMaju = 20;
		}
		maju(ballMaju);
		prevErrorBallMaju=errorBallMaju;
	}
	else{
		errorBall = servoMid - ballXCoor ;
		derivErrorBall = errorBall - prevErrorBall;
		intErrorBall += errorBall;
		ball = (float)KaP * errorBall + (float)KaD * derivErrorBall + (float)KaI * intErrorBall;
		if(ball>50){
			ball = 50;
		}
		else if(ball<15 && ball >0){
			ball = 10;
		}
		else if(ball>-15 && ball<0){
			ball = -10;
		}
		else if (ball <-50){
			ball = -50;
		}
		rotateAntiClockWise(ball);
		prevErrorBall=errorBall;
	}

}

void getGoalPos(void){
	float x,y;
	x = goalX-movX;
	y = goalY-movY;
	headGoal = atan(y/x)*180/PI;
	 if (x>0 && y>0){
	   //kuadran1
	   headGoal = headGoal;
	   }

	 else if (x>0 && y<0){
	   //kuadran2
	   headGoal=headGoal+180;
	   }

	 else if (x<0 && y<0){
	   //kuadran3
	   headGoal=headGoal+180;
	   }

	 else {
	   //kuadran4
	   headGoal	=headGoal+360;
	   }

	 if((compassHeading-headGoal) > -10 && (compassHeading - headGoal) < 10){
		 handleOff();
		 maju(50);
	 }
	 else{
		 if(headGoal>180){
			 rotateClockWise(20);
		 }
		 else if (headGoal<180) {
			rotateAntiClockWise(20);
		}
	 }

	 prevErrorHead=errorHead;

}

void gotoHeadZero(void){
	 if(compassHeading > 350 || compassHeading < 10){
		 //handleRotateOut();
		 maju(50);
	 }
	 else{
		 handleRotateIn();
		 if(compassHeading>180){
			 rotateAntiClockWise(20);
		 }
		 else if (compassHeading<180) {
			rotateClockWise(20);
		}
	 }
}

void getCoor(int headingProcess,int encoderDifference){
    	if(headingProcess == 1){
//    		if(headCount > 586) headCount -= 586;
//    		if(headCount < 0) headCount += 586;
//        	heading = (float)headCount*360/586;
    	}
    	else{
    		mov = (float) encoderDifference/(14*10);
    		if(mov - movPrev > 0.0007 || mov - movPrev < - 0.0007){
    			movX = movX + mov * cos (heading*PI/180);
    			movY = movY + mov * sin (heading*PI/180);
    		}
    		movPrev = mov;
    	}
}

void tesRotateMap(void){
	maju(20);
	Delayms(2000);
	while(compassHeading < (90 * icount)){
		rotateAntiClockWise(20);
	}
	rotateAntiClockWise(0);
	Delayms(2000);
	icount ++;
	if (icount > 4){
		icount = 1;
	}
}


void LCD_InitializeTimer()
{
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);

	// TIM clock = 84 MHz,
	//Update event time = 1 / [(84 * 10^6) / (TIM_Prescaler * TIM_Period)]
    //kalo mau sedetik: pre = 42000-1, per = 2000-1
    TIM_TimeBaseInitTypeDef timerInitStructure;

    timerInitStructure.TIM_Prescaler = 42000-1;
    timerInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
    timerInitStructure.TIM_Period = 1000-1;
    timerInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    timerInitStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM5, &timerInitStructure);
    TIM_Cmd(TIM5, ENABLE);
	TIM_ITConfig(TIM5, TIM_IT_Update, ENABLE);

}
void LCD_EnableTimerInterrupt()
{
    NVIC_InitTypeDef nvicStructure;

    nvicStructure.NVIC_IRQChannel = TIM5_IRQn;
    nvicStructure.NVIC_IRQChannelPreemptionPriority = 0;
    nvicStructure.NVIC_IRQChannelSubPriority = 0;
    nvicStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvicStructure);

}

void TIM5_IRQHandler(){
	if (TIM_GetITStatus(TIM5, TIM_IT_Update) != RESET)
	    {
	        TIM_ClearITPendingBit(TIM5, TIM_IT_Update);
	        printData();
	    }
}

void init_lcdTimer(){
	LCD_InitializeTimer();
	LCD_EnableTimerInterrupt();
}
