#ifndef MEKANSME_PENENDANG_H_
#define MEKANISME_PENENDANG_H_

#include "stdbool.h"

void init_handle();
void init_penendang();
void handleRotateIn();
void handleRotateOut();
void handleOff();
void kick(bool mode);

#endif
