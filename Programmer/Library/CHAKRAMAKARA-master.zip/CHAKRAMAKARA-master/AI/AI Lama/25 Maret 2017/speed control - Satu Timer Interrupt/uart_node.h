#ifndef UART_NODE_H_INCLUDED
#define UART_NODE_H_INCLUDED
void init_node(void);
void USART2_IRQHandler(void);
void getGamestate(void);

#endif // UART_NODE_H_INCLUDED
