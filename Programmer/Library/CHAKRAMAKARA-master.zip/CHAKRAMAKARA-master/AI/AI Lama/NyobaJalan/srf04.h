

// Global Variabel
extern float jarakKanan_Depan;
extern float jarakKanan_Belakang;
extern float jarakDepan_Kanan;
extern float jarakDepan_Kiri;
extern float jarakKiri_Depan;
extern float jarakKiri_Belakang;
extern float jarakBelakang_Kanan;
extern float jarakBelakang_Kiri;

void srf04Init();

void bacaSRFKanan();
void bacaSRFDepan();
void bacaSRFKiri();
void bacaSRFBelakang();
