/* 		
		Pin_Trigger	Pin_Echo
		E10 		E11 				SRFKanan_Depan
		B12 		B13 				SRFKanan_Belakang
		D0 			C12					SRFDepan_Kanan
		B10 		B11 				SRFDepan_Kiri
		C10 		C11 				SRFKiri_Depan
		C14 		C15					SRFKiri_Belakang
		B7 			B6 					SRFBelakang_Kanan
		A3 			A4 					SRFBelakang_Kiri (Belum Fix)
*/

/*
		Library yang diperlukan :
		- srf04.h
		-
		- 
*/

#include "srf04.h"
#include "tm_stm32f4_hcsr04.h"
#include "tm_stm32f4_gpio.h"
#include "tm_stm32f4_delay.h"
	
	TM_HCSR04_t SRFKanan_Depan;
	TM_HCSR04_t SRFKanan_Belakang;
	extern TM_HCSR04_t SRFDepan_Kanan;
	TM_HCSR04_t SRFDepan_Kiri;
	TM_HCSR04_t SRFKiri_Depan;
	TM_HCSR04_t SRFKiri_Belakang;
	TM_HCSR04_t SRFBelakang_Kanan;
	TM_HCSR04_t SRFBelakang_Kiri;

void srf04Init(){
	TM_HCSR04_Init(&SRFKanan_Depan, GPIOE, GPIO_PIN_11, GPIOE, GPIO_PIN_10);
	TM_HCSR04_Init(&SRFKanan_Belakang, GPIOB, GPIO_PIN_13, GPIOB, GPIO_PIN_12);
	TM_HCSR04_Init(&SRFDepan_Kanan, GPIOD, GPIO_PIN_0, GPIOC, GPIO_PIN_12);
	TM_HCSR04_Init(&SRFDepan_Kiri, GPIOB, GPIO_PIN_10, GPIOB, GPIO_PIN_11);
	TM_HCSR04_Init(&SRFKiri_Depan, GPIOC, GPIO_PIN_10, GPIOC, GPIO_PIN_11);
	TM_HCSR04_Init(&SRFKiri_Belakang, GPIOC, GPIO_PIN_14, GPIOC, GPIO_PIN_15);
	TM_HCSR04_Init(&SRFBelakang_Kanan, GPIOB, GPIO_PIN_7, GPIOB, GPIO_PIN_6);
	TM_HCSR04_Init(&SRFBelakang_Kiri, GPIOA, GPIO_PIN_3, GPIOA, GPIO_PIN_4);
}

void bacaSRFKanan(){
	//jarakKanan_Depan = TM_HCSR04_Read(&SRFKanan_Depan) * 3;
	jarakKanan_Belakang = TM_HCSR04_Read(&SRFKanan_Belakang) * 3;
}

void bacaSRFDepan(){
	jarakDepan_Kanan = TM_HCSR04_Read(&SRFDepan_Kanan) * 3;
	//jarakDepan_Kiri = TM_HCSR04_Read(&SRFDepan_Kiri) * 3;
}

void bacaSRFKiri(){
	jarakKiri_Depan = TM_HCSR04_Read(&SRFKiri_Depan) * 3;
	//jarakKiri_Belakang = TM_HCSR04_Read(&SRFKiri_Belakang) * 3;
}

void bacaSRFBelakang(){
	//jarakBelakang_Kanan = TM_HCSR04_Read(&SRFBelakang_Kanan) * 3;
	jarakBelakang_Kiri = TM_HCSR04_Read(&SRFBelakang_Kiri) * 3;
}
