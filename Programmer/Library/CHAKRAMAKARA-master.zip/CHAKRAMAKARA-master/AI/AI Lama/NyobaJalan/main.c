#include "stm32f4xx.h"
//#include "system_stm32f4xx.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_tim.h"
#include "pwm_motor.h"
#include "tm_stm32f4_delay.h"
//#include "srf04.h"
#include "srf.h"
#include "tm_stm32f4_hcsr04.h"
#include "wallFollowing.h"

float jarakKanan_Depan;
float jarakKanan_Belakang;
float jarakDepan_Kanan;
float jarakDepan_Kiri;
float jarakKiri_Depan;
float jarakKiri_Belakang;
float jarakBelakang_Kanan;
float jarakBelakang_Kiri;

int state;
int main(void)
{
	SystemInit();
	//init_pwm();
	TM_DELAY_Init();
	srf04Init();
	i2c_init();
	sonarSetRangeALL();
	//TM_HCSR04_Init(&SRFDepan_Kanan, GPIOD, GPIO_PIN_0, GPIOC, GPIO_PIN_12);
    while(1)
    {
    	//wallFollowing4();
    	//bacaSRFBelakang();
    	//bacaSRFKanan();
    	//bacaSRFKiri();
    	bacaSRFDepan();
    	//jarakDepan_Kanan = TM_HCSR04_Read(&SRFDepan_Kanan) * 3;

    	//sonarRange(0xEC);
    	//jarakBelakang_Kanan = sonarGet(0xEC);


    }
}
