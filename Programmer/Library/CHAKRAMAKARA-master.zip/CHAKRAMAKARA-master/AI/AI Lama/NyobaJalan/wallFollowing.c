/*
	TODO :
		- Buat delay per perubahan state
*/


//#include "srf04.h"
#include "pwm_motor.h"
#include "wallFollowing.h"


#define minimumDistance 30 // Default SRF distance is 4 cm
#define wallDistance 15
#define minimumDistanceFront 15
#define stateMaju 1
#define stateKanan 2
#define stateMundur 3
#define stateKiri 4
#define putarKanan 1
#define putarKiri 2
#define basePwm 20000
#define KP 1000
extern int state;

extern float jarakKanan_Depan;
extern float jarakKanan_Belakang;
extern float jarakDepan_Kanan;
extern float jarakDepan_Kiri;
extern float jarakKiri_Depan;
extern float jarakKiri_Belakang;
extern float jarakBelakang_Kanan;
extern float jarakBelakang_Kiri;

float pwmKiri;
float pwmKanan;

void gantiState(int arah,int parameter){
	if(arah == putarKanan){
		if (parameter == stateKanan){
			Delayms(100);
			berhenti();
			Delayms(50);
//			kanan(pwmKiri, pwmKanan);
//			Delayms(300);
			bacaSRF();
			while(jarakBelakang_Kiri >= minimumDistance){
				kanan(20000, 20000);
				bacaSRF();
			}
			state = stateKanan;
		}
		else if (parameter == stateMaju){
			Delayms(100);
			berhenti();
			Delayms(50);
//			maju(pwmKiri, pwmKanan);
//			Delayms(300);
			bacaSRF();
			while(jarakKanan_Belakang >= minimumDistance){
				maju(20000, 20000);
				bacaSRF();
			}
			state = stateMaju;
		}
		if (parameter == stateKiri){
			Delayms(100);
			berhenti();
			Delayms(50);
//			kiri(pwmKiri, pwmKanan);
//			Delayms(300);
			bacaSRF();
			while(jarakDepan_Kanan >= minimumDistance){
				kiri(20000, 20000);
				bacaSRF();
			}
			state = stateKiri;
		}
		if (parameter == stateMundur){
			Delayms(100);
			berhenti();
			Delayms(50);
//			mundur(pwmKiri, pwmKanan);
//			Delayms(300);
			bacaSRF();
			while(jarakKiri_Depan >= minimumDistance){
				mundur(20000, 20000);
				bacaSRF();
			}
			state = stateMundur;
		}
	}
	if(arah == putarKiri){
		if (parameter == stateKanan){
			berhenti();
			Delayms(50);
			kanan(pwmKiri, pwmKanan);
			Delayms(300);
			state = stateKanan;
		}
		else if (parameter == stateMaju){
			berhenti();
			Delayms(50);
			maju(pwmKiri, pwmKanan);
			Delayms(300);
			state = stateMaju;
		}
		if (parameter == stateKiri){
			berhenti();
			Delayms(50);
			kiri(pwmKiri, pwmKanan);
			Delayms(300);
			state = stateKiri;
		}
		if (parameter == stateMundur){
			berhenti();
			Delayms(50);
			mundur(pwmKiri, pwmKanan);
			Delayms(300);
			state = stateMundur;
		}
	}

}

void aturJarak(int state){
	bacaSRF();
	float selisih;
	if(state == stateMaju){
		selisih = jarakKanan_Belakang - wallDistance;
		if(selisih > 1){
			kanan(10000,10000);
		}
		else if(selisih < -1){
			kanan(-10000,10000);
		}
		else {
			kanan(0,0);
		}
	}
	else if(state == stateKanan){
		selisih = jarakBelakang_Kiri - wallDistance;
		if(selisih > 1){
			mundur(10000,10000);
		}
		else if(selisih < -1){
			mundur(-10000,10000);
		}
		else {
			mundur(0,0);
		}
	}
	else if (state == stateMundur){
		selisih = jarakKiri_Depan - wallDistance;
		if(selisih > 1){
			kiri(10000,10000);
		}
		else if(selisih < -1){
			kiri(-10000,10000);
		}
		else {
			kiri(0,0);
		}
	}
	else{
		selisih = jarakDepan_Kanan - wallDistance;
		if(selisih > 1){
			maju(10000,10000);
		}
		else if(selisih < -1){
			maju(-10000,10000);
		}
		else {
			maju(0,0);
		}
	}
}

void wallFollowing(){

	if(state == stateMaju){

		bacaSRFKanan();
		bacaSRFDepan();

		if(jarakKanan_Depan > minimumDistance && jarakKanan_Belakang > minimumDistance){
			//Motor Berhenti (PWM -1)
			gantiState(putarKanan,stateKanan);
			state = stateKanan;
		}

		else if (jarakDepan_Kanan <= minimumDistance && jarakDepan_Kiri <= minimumDistance){
			//Motor Berhenti (PWM -1)
			state = stateKiri;
			bacaSRFKiri();/*
			if(TODO BISA KE KIRI){
				MAJU KIRI x detik
			}*/
		}

		else{
			//Motor Maju
			//maju(pwmKiri, pwmKanan);
		}

	}

	else if(state == stateKanan){

		bacaSRFKanan();
		bacaSRFBelakang();

		if(jarakBelakang_Kanan > minimumDistance && jarakBelakang_Kiri > minimumDistance){
			//Motor Berhenti (PWM -1)
			state = stateMundur;
		}

		else if (jarakKanan_Depan <= minimumDistance && jarakKanan_Belakang <= minimumDistance){
			//Motor Berhenti (PWM -1)
			state = stateMaju;
		}

		else{
			//Motor Kanan
		}

	}

	else if(state == stateMundur){

		bacaSRFKiri();
		bacaSRFBelakang();

		if(jarakKiri_Depan > minimumDistance && jarakKiri_Belakang > minimumDistance){
			//Motor Berhenti (PWM -1)
			state = stateKiri;
		}

		else if (jarakBelakang_Kanan <= minimumDistance && jarakBelakang_Kiri <= minimumDistance){
			//Motor Berhenti (PWM -1)
			state = stateKanan;
		}

		else{
			//Motor Mundur
		}

	}

	else if(state == stateKiri){

		bacaSRFKiri();
		bacaSRFDepan();

		if(jarakDepan_Kanan > minimumDistance && jarakDepan_Kiri > minimumDistance){
			//Motor Berhenti (PWM -1)
			state = stateMaju;
		}

		else if (jarakKiri_Depan <= minimumDistance && jarakKiri_Belakang <= minimumDistance){
			//Motor Berhenti (PWM -1)
			state = stateMundur;
		}

		else{
			//Motor Kiri
		}

	}

}


void wallFollowing4(){

	if(state == stateMaju){

		bacaSRF();

		if(jarakKanan_Belakang > minimumDistance){
			//Motor Berhenti (PWM -1)
			gantiState(putarKanan,stateKanan);
			state = stateKanan;
		}

		else if (jarakDepan_Kanan <= minimumDistanceFront){
			//Motor Berhenti (PWM -1)
			gantiState(putarKiri,stateKiri);
			state = stateKiri;
			bacaSRFKiri();/*
			if(TODO BISA KE KIRI){
				MAJU KIRI x detik
			}*/
		}

		else{
			//Motor Maju
			aturJarak(stateMaju);

			maju(pwmKiri, pwmKanan);
		}

	}

	else if(state == stateKanan){

		bacaSRF();

		if(jarakBelakang_Kiri > minimumDistance){
			//Motor Berhenti (PWM -1)
			gantiState(putarKanan,stateMundur);
			state = stateMundur;
		}

		else if (jarakKanan_Belakang <= minimumDistanceFront){
			//Motor Berhenti (PWM -1)
			gantiState(putarKiri,stateMaju);
			state = stateMaju;
		}

		else{
			//Motor Kanan
			aturJarak(stateKanan);
			kanan(pwmKiri, pwmKanan);
		}

	}

	else if(state == stateMundur){

		bacaSRF();

		if(jarakKiri_Depan > minimumDistance){
			//Motor Berhenti (PWM -1)
			gantiState(putarKanan,stateKiri);
			state = stateKiri;
		}

		else if (jarakBelakang_Kiri <= minimumDistanceFront){
			//Motor Berhenti (PWM -1)
			gantiState(putarKiri,stateKanan);
			state = stateKanan;
		}

		else{
			//Motor Mundur
			aturJarak(stateMundur);
			mundur(pwmKiri, pwmKanan);
		}

	}

	else if(state == stateKiri){

		bacaSRF();

		if(jarakDepan_Kanan > minimumDistance){
			//Motor Berhenti (PWM -1)
			gantiState(putarKanan,stateMaju);
			state = stateMaju;
		}

		else if (jarakKiri_Depan <= minimumDistanceFront){
			//Motor Berhenti (PWM -1)
			gantiState(putarKiri,stateMundur);
			state = stateMundur;
		}
		else{
			//Motor Kiri
			aturJarak(stateKiri);
			kiri(pwmKiri, pwmKanan);
		}

	}

}
