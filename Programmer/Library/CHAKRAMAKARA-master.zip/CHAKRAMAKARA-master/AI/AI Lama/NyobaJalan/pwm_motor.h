#ifndef PWM_MOTOR_H_
#define PWM_MOTOR_H_

#define kaDepan 1
#define kaBelakang 3
#define kiDepan 2
#define kiBelakang 4

#define servoAtas 5
#define servoKanan 6
#define servoKiri 7
#include <stdint.h>

void TM_TIMER_Init();
void init_pwm();
void init_motor();
void motorDC(uint8_t channel, int32_t pwm);
void tesMotor();
void berhenti();
void maju(int32_t pwmKiri, int32_t pwmKanan);
void mundur(int32_t pwmKiri, int32_t pwmKanan);
void kanan(int32_t pwmKiri, int32_t pwmKanan);
void kiri(int32_t pwmKiri, int32_t pwmKanan);

#endif
