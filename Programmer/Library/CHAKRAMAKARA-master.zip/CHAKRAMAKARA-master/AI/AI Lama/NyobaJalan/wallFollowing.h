#ifndef WALLFOLLOWING_H_
#define WALLFOLLOWING_H_

void wallFollowing();
//void srf04Init();
void wallFollowing4();
//void bacaSRFKanan();
//void bacaSRFDepan();
//void bacaSRFKiri();
//void bacaSRFBelakang();


#endif
