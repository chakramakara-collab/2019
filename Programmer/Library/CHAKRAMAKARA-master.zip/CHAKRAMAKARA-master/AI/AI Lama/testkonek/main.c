/**
 *	Keil project for USART
 *
 *  Before you start, select your target, on the right of the "Load" button
 *
 *	@author		Tilen Majerle
 *	@email		tilen@majerle.eu
 *	@website	http://stm32f4-discovery.com
 *	@ide		Keil uVision 5
 *	@packs		STM32F4xx Keil packs version 2.2.0 or greater required
 *	@stdperiph	STM32F4xx Standard peripheral drivers version 1.4.0 or greater required
 */

/* Include core modules */
#include "stm32f4xx.h"
/* Include my libraries here */
//#include "defines.h"
#include "stm32f4xx_usart.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"
//#include "tm_stm32f4_delay.h"


uint32_t y,x;

//int main(void) {
//
//
//	/* Initialize system */
//	SystemInit();
//
//	/* Initialize USART1 at 9600 baud, TX: PB6, RX: PB7 */
//	TM_USART_Init(USART1, TM_USART_PinsPack_2, 9600);
//	TM_USART_Init(USART2, TM_USART_PinsPack_1, 9600);
//
//	/* Put string to USART */
//	TM_USART_Puts(USART1, "2");
//
//	while (1) {
//		TM_USART_Puts(USART2, "2");
//		/* Get character from internal buffer */
//		c = TM_USART_Getc(USART2);
//		if (c) {
//			/* If anything received, put it back to terminal */
//			TM_USART_Putc(USART2, c);
//		}
//	}
//}

void USART_Configuration(void){
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	// sort out clocks
	RCC_AHB1PeriphClockCmd( RCC_AHB1Periph_GPIOA, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
	/* Configure USART2 Tx (PA.02) as alternate function push-pull */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	// Map USART2 to A.02
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource2, GPIO_AF_USART2);
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource3 , GPIO_AF_USART2);
	// Initialize USART
	USART_InitStructure.USART_BaudRate = 9600;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	/* Configure USART */
	USART_Init(USART2, &USART_InitStructure);
	/* Enable the USART */
	USART_Cmd(USART2, ENABLE);
}

int putcharx(char ch)
{
	while (USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
	USART_SendData(USART2, (uint8_t)ch);
	return ch;
}

int main (){
	 USART_Configuration();
	 while(1){
		 //putcharx("a");
		 x = USART_ReceiveData(USART2);
		 //y = USART_ReceiveData(USART2);
	 }
}
