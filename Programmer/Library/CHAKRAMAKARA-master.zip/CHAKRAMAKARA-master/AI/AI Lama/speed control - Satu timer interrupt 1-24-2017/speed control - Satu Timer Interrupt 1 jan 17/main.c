#include "stm32f4xx_exti.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_syscfg.h"
#include "misc.h"
#include "tm_stm32f4_rotary_encoder.h"
#include "tm_stm32f4_delay.h"
#include "lcd_16x2.h"
#include "pwm_motor.h"
#include <stdio.h>
#include "speed_control.h"
#include <math.h>
#include "uart_node.h"
#define servoMid 84
extern char gameState;
extern char ballXCoor;
float KaP = 1;
float KaD = 2;
float KaI = 0;
float ball,errorBall,derivErrorBall,intErrorBall,prevErrorBall;

void getBall(){
	if((ballXCoor-servoMid) > -15 && (ballXCoor - servoMid) < 15){
		maju(30);
	}
	else{
		errorBall = servoMid - ballXCoor ;
		derivErrorBall = errorBall - prevErrorBall;
		intErrorBall += errorBall;
		ball = (float)KaP * errorBall + (float)KaD * derivErrorBall + (float)KaI * intErrorBall;
		if(ball>30){
			ball = 30;
		}
		else if (ball <-30){
			ball = -30;
		}
		rotateAntiClockWise(ball);
		prevErrorBall=errorBall;
	}

//	if((ballXCoor-servoMid)>15){
//		rotateClockWise(20);
//	}
//	else if ((ballXCoor-servoMid)<-15){
//		rotateAntiClockWise(20);
//	}
//	else {
//		maju(20);
//	}
}
void tesMotor(){
	maju(50);
	Delayms(2000);
	mundur(50);
	Delayms(2000);
	kiri(50);
	Delayms(2000);
	kanan(50);
	Delayms(2000);
	baratLaut(50);
	Delayms(2000);
	tenggara(50);
	Delayms(2000);
	baratDaya(50);
	Delayms(2000);
	timurLaut(50);
	Delayms(2000);
	rotateAntiClockWise(50);
	Delayms(2000);
	rotateClockWise(50);
	Delayms(2000);
}
int main(void)
{
	int i = 0;
	SystemInit();

	lcd_init();
	TM_DELAY_Init();

	lcd_clear();
	init_speed_control();
	init_USART();


    //extern TM_INT_RE_Count;

    //148 = 90 derajat
//    while(TM_INT_RE_Count < 296){
//    	rotateClockWise(20);
//    	rotateClockWise(0);
//
//    }

	//Delayms(11250);


    while(1)
    {

    	//tesMotor();
    	//getBall();
//    	if(gameState=='s'){
//    		getBall();
//    		//tesMotor();
//    	}
//    	else{
   		motorSpeed(0,0,0,30);
//    	}
    }
}
