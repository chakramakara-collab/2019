#ifndef UART_NODE_H_INCLUDED
#define UART_NODE_H_INCLUDED
void init_node(void);
void USART2_IRQHandler(void);
void USART_InitializeTimer();
void USART_EnableTimerInterrupt();
void TIM5_IRQHandler();
void getGamestate(void);

#endif // UART_NODE_H_INCLUDED
