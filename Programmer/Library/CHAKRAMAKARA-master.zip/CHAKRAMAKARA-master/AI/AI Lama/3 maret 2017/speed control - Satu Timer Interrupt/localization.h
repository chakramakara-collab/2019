#ifndef LOCALIZATION_H_
#define LOCALIZATION_H_

void getCoor();

#endif

