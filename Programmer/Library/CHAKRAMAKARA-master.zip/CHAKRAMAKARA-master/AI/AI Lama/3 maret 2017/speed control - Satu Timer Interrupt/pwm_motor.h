#ifndef PWM_MOTOR_H_
#define PWM_MOTOR_H_

void TM_TIMER_Init();
void init_pwm();
void init_motor();
void motorDC(uint8_t channel, int32_t pwm);
void maju(int32_t pwm);
void mundur(int32_t pwm);
void kanan(int32_t pwm);
void kiri(int32_t pwm);
void timurLaut(int32_t pwm);
void tenggara(int32_t pwm);
void baratLaut(int32_t pwm);
void baratDaya(int32_t pwm);
void rotateClockWise(int32_t pwm);
void rotateAntiClockWise(int32_t pwm);

#endif
