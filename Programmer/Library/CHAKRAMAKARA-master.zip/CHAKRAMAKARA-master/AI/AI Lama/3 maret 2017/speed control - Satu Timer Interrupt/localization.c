#include "speed_control.h"
#include <math.h>
#define PI 3.14159265

int headCount;
float heading, mov,movPrev, movX, movY;

void getCoor(int headingProcess,int encoderDifference){
    	if(headingProcess == 1){
//    		if(headCount > 586) headCount -= 586;
//    		if(headCount < 0) headCount += 586;
//        	heading = (float)headCount*360/586;
    	}
    	else{
    		mov = (float) encoderDifference/(14*10);
    		if(mov - movPrev > 0.0007 || mov - movPrev < - 0.0007){
    			movX = movX + mov * cos (heading*PI/180);
    			movY = movY + mov * sin (heading*PI/180);
    		}
    		movPrev = mov;
    	}
}
