// speed_control.c & speed_control.h: Adika Bintang Sulaeman, Jan 16th 2015
// edited Jan 11th 2017 by Yunus Maulana
// update notes : 4 motor with 4 encoder
// This code was tested using Pololu motor 19:1 with encoder with max speed: 200 rpm
// To use this code, one should plug the following cables to the microcrontroller:
<<<<<<< HEAD
// encoder A (yellow) from motor 1 to PD0
// encoder B (white) from motor 1 to PD4
// encoder A (yellow) from motor 2 to PD1
// encoder B (white) from motor 2 to PD5
// encoder A (yellow) from motor 3 to PD2
// encoder B (white) from motor 3 to PD6
// encoder A (yellow) from motor 4 to PD3
// encoder B (white) from motor 4 to PD7
// in1: PB12, in2: PB13, in3: PB14, in4: PB15
=======
// motor 1   : in1: PB12, in2: PB13
// encoder 1 : Yellow PD0, White PD4
// motor 2   : in3: PB14, in4: PB15
// encoder 2 : Yellow PD1, White PD5
// motor 3   : in3: PE12, in4: PE14
// encoder 3 : Yellow PD2, White PD6
// motor 4   : in3: PE13, in4: PE15
// encoder 4 : Yellow PD3, White PD7
>>>>>>> origin/master
// dependencies: as they are included in #include
// Before implementing code in while (1), you have to call void init_speed_control(void) inside int main()
// To set the motor speed, use motorSpeed(kecepatan kiri, kecepatan kanan);
// Credit to: Tilen Majerle (stm32f4-discovery.com)

// Important:
// after initialize, directly call motorSpeed(0,0);
// if you want motor to stop, always motorSpeed(0, 0);
// e.g.: muter: motorSpeed(0,0); motorSpeed(-60,60); Delayms(1000); motorSpeed(0,0);

#include <stm32f4xx_gpio.h>
#include <stm32f4xx_tim.h>
#include <stm32f4xx_rcc.h>
#include <misc.h>
#include "speed_control.h"
#include "tm_stm32f4_rotary_encoder.h"
#include "pwm_motor.h"
#include "stdint.h"

#define KP 10.8 
#define KD 280 
#define KI 0 

int32_t rotaryCount = 0;
int32_t lastCount = 0;
int16_t error = 0;
int16_t errorDua = 0;
int16_t errorTiga = 0;
int16_t errorEmpat = 0;
int32_t rpm = 0;
int32_t rpmDua = 0;
int32_t rpmTiga = 0;
int32_t rpmEmpat = 0;
int16_t setPointSatu = 0;
int16_t setPointDua = 0;
int16_t setPointTiga = 0;
int16_t setPointEmpat = 0;
int32_t output = 0;
int32_t outputDua = 0;
int32_t outputTiga = 0;
int32_t outputEmpat = 0;
int32_t speed = 0;
int16_t prevError = 0;
int16_t derivError = 0;
int16_t intError = 0;
int16_t prevErrorDua = 0;
int16_t derivErrorDua = 0;
int16_t intErrorDua = 0;
int16_t prevErrorTiga = 0;
int16_t derivErrorTiga = 0;
int16_t intErrorTiga = 0;
int16_t prevErrorEmpat = 0;
int16_t derivErrorEmpat = 0;
int16_t intErrorEmpat = 0;

TM_RE_t data;
TM_RE_t data2;
TM_RE_t data3;
TM_RE_t data4;

void InitializeTimer()
{
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
	
	// TIM clock = 84 MHz,
	//Update event time = 1 / [(84 * 10^6) / (TIM_Prescaler * TIM_Period)] 
    //kalo mau sedetik: pre = 42000-1, per = 2000-1
    TIM_TimeBaseInitTypeDef timerInitStructure;

    timerInitStructure.TIM_Prescaler = 42000-1;
    timerInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
    timerInitStructure.TIM_Period = 10-1;
    timerInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    timerInitStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM2, &timerInitStructure);
    TIM_Cmd(TIM2, ENABLE);
	TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);

}

void EnableTimerInterrupt()
{
    NVIC_InitTypeDef nvicStructure;

    nvicStructure.NVIC_IRQChannel = TIM2_IRQn;
    nvicStructure.NVIC_IRQChannelPreemptionPriority = 0;
    nvicStructure.NVIC_IRQChannelSubPriority = 1;
    nvicStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvicStructure);

}

void TIM2_IRQHandler()
{
    if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
    {
        TIM_ClearITPendingBit(TIM2, TIM_IT_Update);

        //update motor 1
        TM_RE_Get(&data);

        rpm = (int32_t)(data.Diff*60*2/8);

        error = setPointSatu - rpm;
        derivError = error - prevError;
        intError += error;
        output += (float)KP * error + (float)KD * derivError + (float)KI * intError;

        if (output > 65534) output = 65534;
        motorDC(1, output);
        prevError = error;

<<<<<<< HEAD
        //
        //

=======
        //update motor 2
>>>>>>> origin/master
        SecondGet(&data2);

        rpmDua = (int32_t)(data2.Diff*60*2/8);

        errorDua = setPointDua - rpmDua;
        derivErrorDua = errorDua - prevErrorDua;
        intErrorDua += errorDua;
        outputDua += (float)KP * errorDua + (float)KD * derivErrorDua + (float)KI * intErrorDua;

        if (outputDua > 65534) outputDua = 65534;
        motorDC(2, outputDua);

        prevErrorDua = errorDua;

        //update motor 3
        ThirdGet(&data3);

        rpmTiga = (int32_t)(data3.Diff*2*60/8);

        errorTiga = setPointTiga - rpmTiga;
        derivErrorTiga = errorTiga - prevErrorTiga;
        intErrorTiga += errorTiga;
        outputTiga += (float)KP * errorTiga + (float)KD * derivErrorTiga + (float)KI * intErrorTiga;

        if (outputTiga > 65534) outputTiga = 65534;
        motorDC(3, outputTiga);

        prevErrorTiga = errorTiga;

        //update motor 4
        FourthGet(&data4);

        rpmEmpat = (int32_t)(data4.Diff*2*60/8);

        errorEmpat = setPointEmpat - rpmEmpat;
        derivErrorEmpat = errorEmpat - prevErrorEmpat;
        intErrorEmpat += errorEmpat;
        outputEmpat += (float)KP * errorEmpat + (float)KD * derivErrorEmpat + (float)KI * intErrorEmpat;

        if (outputEmpat > 65534) outputEmpat = 65534;
        motorDC(4, outputEmpat);

        prevErrorEmpat = errorEmpat;
    }
}

void motorSpeed(int16_t leftBackSpeed, int16_t leftFrontSpeed, int16_t righFrontSpeed, int rightBackSpeed) {
	//these two variables are interchangeably, depending on robots' need
	setPointSatu = leftBackSpeed;
	setPointDua = leftFrontSpeed;
	setPointTiga = righFrontSpeed;
	setPointEmpat = rightBackSpeed;
}

void init_speed_control(void)
{
	InitializeTimer();
	EnableTimerInterrupt();
	TM_RE_Init(&data);
	InitSecondEncoder(&data2);
	InitThirdEncoder(&data3);
	InitFourthEncoder(&data4);
	init_pwm();
	init_motor();
}
