#include "stm32f4xx_exti.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_syscfg.h"
#include "misc.h"
#include "tm_stm32f4_rotary_encoder.h"
#include "tm_stm32f4_delay.h"
#include "lcd_16x2.h"
#include "pwm_motor.h"
#include <stdio.h>
#include "speed_control.h"
#include <math.h>

int main(void)
{
	int i = 0;
	SystemInit();
	//char str[16];

	lcd_init();
	TM_DELAY_Init();

	//lcd_putsf(0,0,"tes");
	//Delayms(1200);
	lcd_clear();
	init_speed_control();
<<<<<<< HEAD
	//motorSpeed(0, 0);
=======
	motorSpeed(0, 0, 0, 0);
>>>>>>> origin/master

    while(1)
    {
//    	motorDC(2,20000);
//    	Delayms(300);
//    	motorDC(2,-20000);
//    	Delayms(300);
    	for (i = -200; i < 200; i++) {
<<<<<<< HEAD
    		motorSpeed(i, i);

=======
    		motorSpeed(i, i, i, i);
>>>>>>> origin/master
    		Delayms(10);
    	}
    	for (; i > -200; i--) {
    		motorSpeed(i, i, i, i);
    		Delayms(10);
    	}
//    	motorSpeed(100,100);
    	/*for (setPointSatu = -200; setPointSatu < 200; setPointSatu++) {
    		Delayms(20);
    	}
    	for (; setPointSatu > -200; setPointSatu--) {
    		Delayms(20);
    	}*/
    }
}
