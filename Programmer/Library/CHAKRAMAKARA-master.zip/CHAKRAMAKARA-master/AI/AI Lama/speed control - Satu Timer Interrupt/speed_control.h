#ifndef SPEED_CONTROL_H_
#define SPEED_CONTROL_H_


void InitializeTimer();
void EnableTimerInterrupt();
void TIM2_IRQHandler();
void TIM5_IRQHandler();
void init_speed_control(void);
void motorSpeed(int16_t leftBackSpeed, int16_t leftFrontSpeed, int16_t righFrontSpeed, int rightBackSpeed);

#endif //SPEED_CONTROL_H_
