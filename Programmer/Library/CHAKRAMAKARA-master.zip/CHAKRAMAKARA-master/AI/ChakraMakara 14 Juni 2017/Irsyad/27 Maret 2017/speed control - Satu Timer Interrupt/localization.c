// Pin data dari proximity masuk ke pin B3
#include "localization.h"
#include "speed_control.h"
#include "mekanisme_penendang.h"
#include <math.h>
#include "uart_node.h"
#include "uart_camera.h"
#include "uart_kompas.h"
#include "tm_stm32f4_delay.h"
#include "lcd_16x2.h"
#include "stdbool.h"
#include "stdio.h"

char lcd[16];
float KaP = 1;
float KaD = 2;
float KaI = 0;
float ball,errorBall,derivErrorBall,intErrorBall,prevErrorBall;
float ballMaju,errorBallMaju,derivErrorBallMaju,intErrorBallMaju,prevErrorBallMaju;
float heading;
float head,errorHead,derivErrorHead,intErrorHead,prevErrorHead;
float headGoal;
int headCount;
float heading, mov,movPrev, movX, movY;
extern uint16_t compassHeading;
extern char gameState;
extern char ballXCoor;
extern char ballYCoor;
extern float movY;
extern float movX;
extern int findBall;

int icount = 1;
int bendera = 0;
int flag = 0;

/**
 * Start main merupakan fungsi utama program robot
 * fungsi ini akan mencari bola, dan gawang
 * @param refree untuk menentukan akan menggunakan refree atau tidak
 * @param mode untuk mengarahkan ke area musuh saja atau mengarahkan ke gawang musuh
 *
 */
void startMain(int refree, int arahGawang){

	if(refree == ON ){
		if (gameState == 's') {
			if(ballYCoor>0){
				getBall();
				if(ballYCoor<20){
					handleRotateIn();
				}
				else{
					handleOff();
				}
			}
			else{
	//			if(arahGawang == ON){
	//				getGoalPos();
	//			}

	//			else{
					handleOff();
					gotoHeadZero();
	//			}
			}
		}
		else if(gameState == 'T'){
			outBall1();
		}
		else if (gameState == 't') {
			outBall2();
		}
		else if (gameState == 'K')
		{
			kickOff1();
		}
		else if (gameState == 'k')
		{
			kickOff2();
		}
		else{
			handleOff();
			motorSpeed(0,0,0,0);
		}

	}
	// refree off
	else{
		if(ballYCoor>0){
			getBall();
			if(ballYCoor<20){
				handleRotateIn();
			}
			else{
				handleOff();
			}
		}
		else{
//			if(arahGawang == ON){
//				getGoalPos();
//			}

//			else{
				handleOff();
				if (gotoHeadZero())
				{
					kickBall();
				}
//			}
		}

	}
}

/*
 * outBall1 merupakan fungsi untuk mengambil posisi sebelum kita throw in
 * fungsi ini akan menggerakkan robot mendekati bola dengan jarak
 */
void outBall1()
{
	if(ballYCoor >= 40 && ballYCoor <= 45)
	{
		motorSpeed(0,0,0,0);
	}
	else if(ballYCoor < 40)
	{
		mundur(30);
	}
	else
	{
		getBall();
	}
}

/*
 * outBall2 merupakan fungsi untuk mengambil posisi sebelum musuh throw in
 * fungsi ini akan menggerakkan robot mendekati bola dengan jarak 1.5 meter
 */
void outBall2()
{
	if(ballYCoor >= 120 &&  ballYCoor <= 125)
	{
		motorSpeed(0,0,0,0);
	}
	else if(ballYCoor < 120)
	{
		mundur(30);
	}
	else
	{
		getBall();
	}
}

/*
 * penalty merupakan fungsi untuk mengambil posisi sebelum penalty
 * fungsi ini akan menggerakkan robot mendekati bola
 */
void penalty(){
	if(ballYCoor>2){
		//getBall();
		maju(100);
		//handleOn();
	}
	else{
		while(1){
			motorSpeed(0,0,0,0);
		}
	}
}

void kickOff1()
{
	if(bendera == 0)
	{
		if(ballYCoor >= 50 && ballYCoor <= 55)
		{
			if(compassHeading >= 315 || compassHeading == 0)
			{
				rotateAntiClockWise(PID(compassHeading,0));
				kiri(40);
				Delayms(3500);
				maju(40);
				Delayms(5000);
				bendera = 1;
			}
			else if(compassHeading >= 270 && compassHeading < 315)
			{
				rotateAntiClockWise(PID(compassHeading,0));
				kiri(40);
				Delayms(2500);
				maju(40);
				Delayms(4000);
				bendera = 1;
			}
			else if(compassHeading > 0 && compassHeading <= 45)
			{
				rotateClockWise(PID(compassHeading,0));
				kanan(40);
				Delayms(3500);
				maju(40);
				Delayms(5000);
				bendera = 1;
			}
			else if(compassHeading > 45 && compassHeading <= 90)
			{
				rotateAntiClockWise(PID(compassHeading,0));
				kanan(40);
				Delayms(2500);
				maju(40);
				Delayms(4000);
				bendera = 1;
			}
		}
		else if(ballYCoor < 50)
		{
			mundur(30);
		}
		else
		{
			getBall();
		}
	}
	else if (bendera == 1)
	{
		rotateClockWise(20);
		if((ballXCoor-servoMid) > -15 && (ballXCoor - servoMid) < 15)
		{
			getBall();
			if(ballYCoor >= 50 && ballYCoor <= 55)
			{
				bendera = 2;
			}
		}
	}
	else if (bendera == 2)
	{
		motorSpeed(0,0,0,0);
	}
}

void kickOff2()
{
	if(bendera == 0)
	{
		if(ballYCoor >= 50 && ballYCoor <= 55)
		{
			if(compassHeading >= 315 || compassHeading == 0)
			{
				rotateAntiClockWise(PID(compassHeading,0));
				kiri(40);
				Delayms(3500);
				maju(40);
				Delayms(5000);
				bendera = 1;
			}
			else if(compassHeading >= 270 && compassHeading < 315)
			{
				rotateAntiClockWise(PID(compassHeading,0));
				kiri(40);
				Delayms(2500);
				maju(40);
				Delayms(4000);
				bendera = 1;
			}
			else if(compassHeading > 0 && compassHeading <= 45)
			{
				rotateClockWise(PID(compassHeading,0));
				kanan(40);
				Delayms(3500);
				maju(40);
				Delayms(5000);
				bendera = 1;
			}
			else if(compassHeading > 45 && compassHeading <= 90)
			{
				rotateAntiClockWise(PID(compassHeading,0));
				kanan(40);
				Delayms(2500);
				maju(40);
				Delayms(4000);
				bendera = 1;
			}
		}
		else if(ballYCoor < 50)
		{
			mundur(30);
		}
		else
		{
			getBall();
		}
	}
	else if (bendera == 1)
	{
		rotateClockWise(20);
		if((ballXCoor-servoMid) > -15 && (ballXCoor - servoMid) < 15)
		{
			getBall();
			if(ballYCoor >= 50 && ballYCoor <= 55)
			{
				bendera = 2;
			}
		}
	}
	else if (bendera == 2)
	{
		motorSpeed(0,0,0,0);
	}
}

void printData(){
	lcd_clear();
	int xCoor,yCoor;
	xCoor = movX;
	yCoor = movY;
	sprintf(lcd,"H:%d Y:%d X:%d ",compassHeading,yCoor,xCoor);
	lcd_putsf(0,0,lcd);
	sprintf(lcd, "G:%d y:%d x:%d",findBall,ballYCoor,ballXCoor);
	lcd_putsf(0,1,lcd);
}

/*
 *
 */
void init_proximity()
{
	GPIO_InitTypeDef gpio_init;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

	gpio_init.GPIO_Pin  = GPIO_Pin_0 | GPIO_Pin_1;
	gpio_init.GPIO_Mode = GPIO_Mode_IN;
	gpio_init.GPIO_Speed = GPIO_Speed_100MHz;
	gpio_init.GPIO_OType = GPIO_OType_PP;
	gpio_init.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOE, &gpio_init);
}

/*
 * getProxy merupakan fungsi untuk menghasilkan nilai 0 atau 1
 * dari inputan proximity
 */
int getProxy()
{
	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == Bit_SET || GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_1) == Bit_SET)
	{
		return 1;
	}

	else
	{
		return 0;
	}
}

/*
 * ballGet merupakan fungsi untuk mengetahui apakah
 * robot telah mendapatkan bola atau belum dengan
 * menggunakan proximity
 * fungsi ini akan memutar hadle jika telah mendapatkan bola
 * dan mencari apabila belum
 */
void ballGet()
{
	if (getProxy() == 0)
	{
		handleRotateIn();
		if(compassHeading>180)
		{
			rotateAntiClockWise(20);
		}
		else if (compassHeading<180)
		{
			rotateClockWise(20);
		}
	}
	else
	{
		handleOff();
		getBall();
	}
}

void getBall(void){
	if((ballXCoor-servoMid) > -15 && (ballXCoor - servoMid) < 15){
		errorBallMaju =  ballYCoor ;
		derivErrorBallMaju = errorBallMaju - prevErrorBallMaju;
		intErrorBallMaju += errorBallMaju;
		ballMaju = (float)KaP * errorBallMaju + (float)KaD * derivErrorBallMaju + (float)KaI * intErrorBallMaju;
		if(ballMaju>50){
			ballMaju = 30;
		}
		else if(ballMaju<20){
			ballMaju = 20;
		}
		maju(ballMaju);
		prevErrorBallMaju=errorBallMaju;
	}
	else{
		errorBall = servoMid - ballXCoor ;
		derivErrorBall = errorBall - prevErrorBall;
		intErrorBall += errorBall;
		ball = (float)KaP * errorBall + (float)KaD * derivErrorBall + (float)KaI * intErrorBall;
		if(ball>50){
			ball = 50;
		}
		else if(ball<15 && ball >0){
			ball = 10;
		}
		else if(ball>-15 && ball<0){
			ball = -10;
		}
		else if (ball <-50){
			ball = -50;
		}
		rotateAntiClockWise(ball);
		prevErrorBall=errorBall;
	}

}

int PID(int param, int desire){
	int temp;
	errorBall = desire - param ;
	derivErrorBall = errorBall - prevErrorBall;
	intErrorBall += errorBall;
	temp = (float)KaP * errorBall + (float)KaD * derivErrorBall + (float)KaI * intErrorBall;
	if(temp>30){
		temp = 30;
	}
	else if(temp<10 && temp >0){
		temp = 5;
	}
	else if(temp>-10 && temp<0){
		temp = -5;
	}
	else if (temp <-30){
		temp = -30;
	}
	prevErrorBall=errorBall;
	return temp;
}

void getGoalPos(void){
	float x,y;
	x = goalX-movX;
	y = goalY-movY;
	headGoal = atan(y/x)*180/PI;
	 if (x>0 && y>0){
	   //kuadran1
	   headGoal = headGoal;
	   }

	 else if (x>0 && y<0){
	   //kuadran2
	   headGoal=headGoal+180;
	   }

	 else if (x<0 && y<0){
	   //kuadran3
	   headGoal=headGoal+180;
	   }

	 else {
	   //kuadran4
	   headGoal	=headGoal+360;
	   }

	 if((compassHeading-headGoal) > -10 && (compassHeading - headGoal) < 10){
		 handleOff();
		 maju(50);
	 }
	 else{
		 if(headGoal>180){
			 rotateClockWise(20);
		 }
		 else if (headGoal<180) {
			rotateAntiClockWise(20);
		}
	 }

	 prevErrorHead=errorHead;

}

bool gotoHeadZero(void){
	 if(compassHeading > 350 || compassHeading < 10){
		 //handleRotateOut();
		 //maju(50);
		 return true;
	 }
	 else{
		 handleRotateIn();
		 if(compassHeading>180){
			 rotateAntiClockWise(20);
		 }
		 else if (compassHeading<180) {
			rotateClockWise(20);
		}
		 return false;
	 }
}

void getCoor(int headingProcess,int encoderDifference){
    	if(headingProcess == 1){
//    		if(headCount > 586) headCount -= 586;
//    		if(headCount < 0) headCount += 586;
//        	heading = (float)headCount*360/586;
    	}
    	else{
    		mov = (float) encoderDifference/(14);
    		if(mov - movPrev > 0.0007 || mov - movPrev < - 0.0007){
    			movX = movX + mov * cos (compassHeading*PI/180);
    			movY = movY + mov * sin (compassHeading*PI/180);
    		}
    		movPrev = mov;
    	}
}

void gotoXY(int coorX, int coorY)
{
	int flag = 0;
	while (1)
	{
		if (flag == 0)
		{
			if (compassHeading >= 357 || compassHeading <= 2)
			{
				maju(30);
//				if ((int)movX + 2 == coorX)
//				{
//					maju(PID(movX,coorX));
//				}
				if ((int)movX == coorX)
				{
					while (1)
					{
						motorSpeed(0,0,0,0);
					}
					flag = 1;
				}
			}
			else
			{
				if(compassHeading<180){
					rotateAntiClockWise(PID(compassHeading,0));
				}
				else if (compassHeading>180) {
					rotateClockWise(PID(compassHeading,0));
				}
			}

		}
		else if (flag == 1)
		{
			if (compassHeading >= 87 && compassHeading <= 92)
			{
				maju(PID(movY,coorY));
				if ((int)movY == coorY)
				{
					while (1)
					{
						motorSpeed(0,0,0,0);
					}
				}
			}
			else
			{
				if(compassHeading<180){
					rotateAntiClockWise(PID(compassHeading,90));
				}
				else if (compassHeading>180) {
					rotateClockWise(PID(compassHeading,90));
				}
			}
		}
	}
}

void tesRotateMap(void){
	int icount=1;
	while(compassHeading > (90 * icount)+2){
		rotateAntiClockWise(PID(compassHeading,(90 * icount)+2));
	}
	while(1){
		if(icount == 1){
				while(compassHeading > (90 * icount)+2){
					rotateAntiClockWise(PID(compassHeading,(90 * icount)+2));
				}
		}

		while(compassHeading < (90 * icount)){
			rotateAntiClockWise(PID(compassHeading,(90 * icount) ));
		}
		maju(20);
		Delayms(2000);
		rotateAntiClockWise(0);
		Delayms(2000);
		icount+=2;
		if (icount > 3){
			icount = 1;
		}
	}
}


void LCD_InitializeTimer()
{
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);

	// TIM clock = 84 MHz,
	//Update event time = 1 / [(84 * 10^6) / (TIM_Prescaler * TIM_Period)]
    //kalo mau sedetik: pre = 42000-1, per = 2000-1
    TIM_TimeBaseInitTypeDef timerInitStructure;

    timerInitStructure.TIM_Prescaler = 42000-1;
    timerInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
    timerInitStructure.TIM_Period = 1000-1;
    timerInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    timerInitStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM5, &timerInitStructure);
    TIM_Cmd(TIM5, ENABLE);
	TIM_ITConfig(TIM5, TIM_IT_Update, ENABLE);

}
void LCD_EnableTimerInterrupt()
{
    NVIC_InitTypeDef nvicStructure;

    nvicStructure.NVIC_IRQChannel = TIM5_IRQn;
    nvicStructure.NVIC_IRQChannelPreemptionPriority = 0;
    nvicStructure.NVIC_IRQChannelSubPriority = 0;
    nvicStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvicStructure);

}

void TIM5_IRQHandler(){
	if (TIM_GetITStatus(TIM5, TIM_IT_Update) != RESET)
	    {
	        TIM_ClearITPendingBit(TIM5, TIM_IT_Update);
	        printData();
	    }
}

void init_lcdTimer(){
	LCD_InitializeTimer();
	LCD_EnableTimerInterrupt();
}
