#!/bin/bash
cd `dirname $0`
cd ..

cat TODO 
