#ifndef OTA_H
#define OTA_H

void otaInit(int port);

#endif
