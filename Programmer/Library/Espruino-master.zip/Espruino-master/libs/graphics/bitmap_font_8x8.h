extern const unsigned char LCD_FONT_8X8[128][8];
