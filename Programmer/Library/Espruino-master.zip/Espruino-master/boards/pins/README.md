Pin Definitions
=============

The files in this directory have been compiled from the microcontroller datasheets. They are read by various scripts during Espruino's compilation and are used to automatically set the correct Alternate Function registers.
